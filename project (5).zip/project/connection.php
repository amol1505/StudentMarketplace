<?php>
session_start();
$con=mysqli_connect('178.128.37.54', 'ad959_admin', 'Rv~8;%*4um&m', 'ad959_products');
?>